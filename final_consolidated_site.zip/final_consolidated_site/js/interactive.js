class InteractiveBackground {
    constructor() {
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
        document.getElementById('interactive-background').appendChild(this.canvas);
        this.canvas.style.position = 'fixed';
        this.canvas.style.top = '0';
        this.canvas.style.left = '0';
        this.canvas.style.width = '100%';
        this.canvas.style.height = '100%';
        this.canvas.style.zIndex = '-1';
        this.canvas.style.pointerEvents = 'none';

        this.particles = [];
        this.mouse = { x: null, y: null, radius: 100 };

        window.addEventListener('resize', () => this.resize());
        window.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        window.addEventListener('touchmove', (e) => this.handleTouchMove(e));

        this.resize();
        this.init();
        this.animate();
    }

    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
        this.init();
    }

    init() {
        this.particles = [];
        const numberOfParticles = (this.canvas.height * this.canvas.width) / 9000;
        for (let i = 0; i < numberOfParticles; i++) {
            const size = Math.random() * 5 + 1;
            const x = Math.random() * (this.canvas.width - size * 2);
            const y = Math.random() * (this.canvas.height - size * 2);
            const directionX = Math.random() * 2 - 1;
            const directionY = Math.random() * 2 - 1;
            const color = `hsla(${Math.random() * 360}, 100%, 50%, 0.8)`;

            this.particles.push(new Particle(this, x, y, directionX, directionY, size, color));
        }
    }

    handleMouseMove(event) {
        this.mouse.x = event.x;
        this.mouse.y = event.y;
    }

    handleTouchMove(event) {
        if (event.touches.length > 0) {
            this.mouse.x = event.touches[0].clientX;
            this.mouse.y = event.touches[0].clientY;
        }
    }

    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        for (let i = 0; i < this.particles.length; i++) {
            this.particles[i].update();
            this.particles[i].draw();
        }
        this.connectParticles();
        requestAnimationFrame(() => this.animate());
    }

    connectParticles() {
        for (let a = 0; a < this.particles.length; a++) {
            for (let b = a; b < this.particles.length; b++) {
                const distance = ((this.particles[a].x - this.particles[b].x) * (this.particles[a].x - this.particles[b].x)) +
                                 ((this.particles[a].y - this.particles[b].y) * (this.particles[a].y - this.particles[b].y));
                if (distance < (this.canvas.width/7) * (this.canvas.height/7)) {
                    this.ctx.strokeStyle = `rgba(255,255,255,${1 - distance/20000})`;
                    this.ctx.lineWidth = 1;
                    this.ctx.beginPath();
                    this.ctx.moveTo(this.particles[a].x, this.particles[a].y);
                    this.ctx.lineTo(this.particles[b].x, this.particles[b].y);
                    this.ctx.stroke();
                }
            }
        }
    }
}

class Particle {
    constructor(parent, x, y, directionX, directionY, size, color) {
        this.parent = parent;
        this.x = x;
        this.y = y;
        this.directionX = directionX;
        this.directionY = directionY;
        this.size = size;
        this.color = color;
    }

    update() {
        if (this.x > this.parent.canvas.width || this.x < 0) {
            this.directionX = -this.directionX;
        }
        if (this.y > this.parent.canvas.height || this.y < 0) {
            this.directionY = -this.directionY;
        }

        let dx = this.parent.mouse.x - this.x;
        let dy = this.parent.mouse.y - this.y;
        let distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < this.parent.mouse.radius) {
            if (this.parent.mouse.x < this.x && this.x < this.parent.canvas.width - this.size * 10) {
                this.x += 10;
            }
            if (this.parent.mouse.x > this.x && this.x > this.size * 10) {
                this.x -= 10;
            }
            if (this.parent.mouse.y < this.y && this.y < this.parent.canvas.height - this.size * 10) {
                this.y += 10;
            }
            if (this.parent.mouse.y > this.y && this.y > this.size * 10) {
                this.y -= 10;
            }
        }
        this.x += this.directionX;
        this.y += this.directionY;
    }

    draw() {
        this.parent.ctx.beginPath();
        this.parent.ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        this.parent.ctx.fillStyle = this.color;
        this.parent.ctx.fill();
    }
}

// Initialize the interactive background
document.addEventListener('DOMContentLoaded', () => {
    new InteractiveBackground();
});

// Parallax scrolling effect
window.addEventListener('scroll', () => {
    const scrollY = window.pageYOffset;
    const heroContent = document.querySelector('.hero-content');
    const projects = document.querySelector('.projects');

    if (heroContent) {
        heroContent.style.transform = `translateY(${scrollY * 0.5}px)`;
    }

    if (projects) {
        projects.style.transform = `translateY(${(scrollY - projects.offsetTop) * 0.1}px)`;
    }
});

// Enhance project cards with 3D effect
const projectCards = document.querySelectorAll('.project-card');
projectCards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;

        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.05, 1.05, 1.05)`;
    });

    card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
    });
});